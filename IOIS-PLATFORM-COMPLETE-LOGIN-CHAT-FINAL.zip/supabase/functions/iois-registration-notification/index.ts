import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
};

function text(v: unknown) { return String(v ?? "").trim(); }
function esc(v: unknown) { return text(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function json(status: number, body: Record<string, unknown>) { return new Response(JSON.stringify(body), { status, headers: corsHeaders }); }

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { ok: false, error: "Method not allowed" });

  const botToken = Deno.env.get("TELEGRAM_BOT_TOKEN");
  const chatId = Deno.env.get("TELEGRAM_CHAT_ID");
  if (!botToken || !chatId) return json(503, { ok: false, error: "Telegram secrets are not configured" });

  let body: any;
  try { body = await req.json(); } catch { return json(400, { ok: false, error: "Invalid JSON" }); }
  const data = body?.data ?? body ?? {};
  if (text(body?.event || data?.event) !== "new_registration") return json(400, { ok: false, error: "Unsupported event" });

  const message = [
    "<b>🇮🇳 IOIS NEW REGISTRATION</b>", "",
    `<b>User ID:</b> ${esc(data.userID)}`,
    `<b>Name:</b> ${esc(data.name)}`,
    `<b>Email:</b> ${esc(data.email)}`,
    `<b>WhatsApp:</b> ${esc(data.whatsapp)}`,
    `<b>Plan:</b> ${esc(data.plan)}`,
    `<b>Amount:</b> ₹${esc(data.amount)}`,
    `<b>Direct Payout:</b> ₹${esc(data.directPayout)}`,
    `<b>Sponsor ID:</b> ${esc(data.sponsorID)}`,
    `<b>Sponsor Name:</b> ${esc(data.sponsorName)}`,
    `<b>Withdrawal:</b> ${esc(data.withdrawalUPI)}`,
    `<b>Payment UPI:</b> ${esc(data.paymentUPI)}`,
    `<b>Registered:</b> ${esc(data.createdAt || new Date().toISOString())}`,
  ].join("\n");

  const telegram = await fetch(`https://api.telegram.org/bot${encodeURIComponent(botToken)}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: "HTML", disable_web_page_preview: true }),
  });

  if (!telegram.ok) {
    console.error("Telegram error", await telegram.text());
    return json(502, { ok: false, error: "Telegram delivery failed" });
  }
  return json(200, { ok: true });
});
