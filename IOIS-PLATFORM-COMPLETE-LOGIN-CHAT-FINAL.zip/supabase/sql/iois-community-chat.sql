-- IOIS Community Chat Hub

-- Ensure the admin_profiles contract expected by the existing admin page exists.
create table if not exists public.admin_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'admin',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.admin_profiles add column if not exists role text;
alter table public.admin_profiles add column if not exists active boolean;

-- Run this in Supabase SQL Editor.
-- Frontend uses only the publishable/anon key. Never place service_role here.

create table if not exists public.community_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  sender_name text,
  sender_avatar_url text,
  message text not null check (char_length(trim(message)) between 1 and 1000),
  created_at timestamptz not null default now()
);

create index if not exists community_messages_created_at_idx
  on public.community_messages (created_at desc);

create index if not exists community_messages_user_id_idx
  on public.community_messages (user_id);

alter table public.community_messages enable row level security;

create or replace function public.iois_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admin_profiles ap
    where ap.user_id = auth.uid()
      and coalesce(ap.active, true) = true
      and coalesce(ap.role, 'admin') in ('admin','super_admin','administrator')
  );
$$;


drop policy if exists "IOIS members can read community messages" on public.community_messages;
create policy "IOIS members can read community messages"
  on public.community_messages
  for select to authenticated
  using ((select auth.uid()) is not null);

drop policy if exists "IOIS members can send own community messages" on public.community_messages;
create policy "IOIS members can send own community messages"
  on public.community_messages
  for insert to authenticated
  with check ((select auth.uid()) = user_id);

drop policy if exists "IOIS members can delete own community messages" on public.community_messages;
create policy "IOIS members can delete own community messages"
  on public.community_messages
  for delete to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "IOIS admins can moderate community messages" on public.community_messages;
create policy "IOIS admins can moderate community messages"
  on public.community_messages
  for delete to authenticated
  using ((select public.iois_is_admin()));

create or replace function public.iois_set_chat_sender()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  u record;
begin
  select id, raw_user_meta_data into u from auth.users where id = new.user_id;
  new.sender_name := coalesce(
    nullif(trim(new.sender_name), ''),
    nullif(trim(u.raw_user_meta_data->>'full_name'), ''),
    'IOIS Member'
  );
  new.sender_avatar_url := coalesce(
    nullif(trim(new.sender_avatar_url), ''),
    nullif(trim(u.raw_user_meta_data->>'avatar_url'), '')
  );
  return new;
end;
$$;

drop trigger if exists trg_iois_set_chat_sender on public.community_messages;
create trigger trg_iois_set_chat_sender
before insert on public.community_messages
for each row execute function public.iois_set_chat_sender();

grant select, insert, delete on public.community_messages to authenticated;

-- Enable Supabase Realtime for live chat. Safe to run more than once.
do $$
begin
  begin
    alter publication supabase_realtime add table public.community_messages;
  exception when duplicate_object then
    null;
  end;
end $$;
